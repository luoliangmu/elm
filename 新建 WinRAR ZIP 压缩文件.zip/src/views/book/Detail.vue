<template>

</template>

<script>
    export default {
        name: "Detail"
    }
</script>

<style scoped>

</style>