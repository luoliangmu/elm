<template>
book
</template>

<script>
    export default {
        name: "List",
    }
</script>

<style scoped>

</style>